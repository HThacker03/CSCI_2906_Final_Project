//  ContentView.swift
//  Kidz Games
//  Created by Student on 11/12/25.

import SwiftUI

struct ContentView: View {
    let game1: String = "Animal Sounds"
    let game2: String = "Bubble Pop"
    let game3: String = "Color Matching"
    let game4: String = "Math Games"
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Kidz Games!")
                .font(.headline)
        }
        .padding(.top, 25)
        
        
        NavigationStack {
            NavigationLink (destination: AnimalSounds(showGame: game1)) {
                Rectangle()
                    .fill(Color.yellow)
                    .frame(width: 280, height: 130)
                    .overlay {
                        Text(game1)
                            .font(.title)
                            .foregroundColor(.black)

                    }
            }
            .padding()
            NavigationLink (destination: BubblePop(showGame: game2)) {
                Circle()
                    .fill(Color.green)
                    .frame(width: 250, height: 180)
                    .overlay {
                        Text(game2)
                            .font(.title)
                            .foregroundColor(.black)

                    }
            }
            .padding()
            NavigationLink (destination: ColorMatching(showGame: game3)) {
               Ellipse()
                    .fill(Color.blue)
                    .overlay {
                        Text(game3)
                            .font(.title)
                            .foregroundColor(.black)
                    }
            }
            .padding()
            NavigationLink (destination: MathGames(showGame: game4)) {
                Triangle()
                    .fill(Color.red)
                    .overlay {
                        Text(game4)
                            .font(.title)
                            .foregroundColor(.black)
                    }
            }
            .padding()
            .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    ContentView()
}
