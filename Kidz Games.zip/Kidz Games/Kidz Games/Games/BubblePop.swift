//
//  BubblePop.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct BubblePop: View {
    let showGame: String
    var body: some View {
        Text(showGame)
    }
}

#Preview {
    BubblePop(showGame: "Game")
}
