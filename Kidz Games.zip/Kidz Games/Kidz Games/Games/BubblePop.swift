//
//  BubblePop.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI
import AVFoundation

struct BubblePop: View {
    @State private var audioPlayer: AVAudioPlayer?
    @State private var randomColor = [Color.red, Color.blue, Color.green, Color.orange, Color.purple].randomElement()!
    @State private var randomSize = Int.random(in: 100...300)
    @State private var randomX = Int.random(in: 100...300)
    @State private var randomY = Int.random(in: 100...600)
    @State private var popCount = 0
    let showGame: String
    var body: some View {
        VStack {
            Text(showGame)
            Text("Score: \(popCount)")
        }
        Spacer()
        
        Button (action: {
            playSound(soundName: "BubblePop", soundType: "mp3")
            randomSize = Int.random(in: 100...300)
            randomX = Int.random(in: 100...300)
            randomY = Int.random(in: 100...700)
            randomColor = [Color.red, Color.blue, Color.green, Color.orange, Color.purple].randomElement()!
            popCount += 1
        }){
            Circle()
                .stroke(randomColor, lineWidth: 10)
                .fill(randomColor)
                .opacity(0.2)
                .frame(width: CGFloat(randomSize))
        }
        .position(x: CGFloat(randomX), y: CGFloat(randomY))
    }
    
    func playSound(soundName: String, soundType: String) {
            if let url = Bundle.main.url(forResource: soundName, withExtension: soundType) {
                do {
                    try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
                    try AVAudioSession.sharedInstance().setActive(true)

                    audioPlayer = try AVAudioPlayer(contentsOf: url)
                    audioPlayer?.play()
                } catch {
                    print("Error playing sound: \(error.localizedDescription)")
                }
            } else {
                print("Sound file not found")
            }
        }
}

#Preview {
    BubblePop(showGame: "Game")
}
