//
//  MathGames.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct MathGames: View {
    let showGame: String
    
    var body: some View {
        VStack{
            Text(showGame)
                .font(.title)
        }
        NavigationStack {
            VStack {
                HStack {
                    NavigationLink(destination: AdditionGame()) {
                        Rectangle()
                            .fill(Color.yellow)
                            .frame(width: 175, height: 175)
                            .cornerRadius(25)
                            .overlay {
                                Text("Addition\n \(Image(systemName: "plus"))")
                                    .font(.title)
                                    .foregroundColor(.black)
                                
                            }
                    }
                    .padding()
                    NavigationLink(destination: SubtractionGame()) {
                        Rectangle()
                            .fill(Color.purple)
                            .frame(width: 175, height: 175)
                            .cornerRadius(25)
                            .overlay {
                                Text("Subtraction\n \(Image(systemName: "minus"))")
                                    .font(.title)
                                    .foregroundColor(.black)
                                
                            }
                    }
                    .padding()
                }
                HStack {
                    NavigationLink(destination: MultiplicationGame()) {
                        Rectangle()
                            .fill(Color.pink)
                            .frame(width: 175, height: 175)
                            .cornerRadius(25)
                            .overlay {
                                Text("Multiply\n \(Image(systemName: "multiply"))")
                                    .font(.title)
                                    .foregroundColor(.black)
                            }
                    }
                    .padding()
                    NavigationLink(destination: DivisionGame()) {
                        Rectangle()
                            .fill(Color.cyan)
                            .frame(width: 175, height: 175)
                            .cornerRadius(25)
                            .overlay {
                                Text("Divide\n \(Image(systemName: "divide"))")
                                    .font(.title)
                                    .foregroundColor(.black)
                            }
                    }
                    .padding()
                }
            }
        }
    }
}

#Preview {
    MathGames(showGame: "Game")
}
