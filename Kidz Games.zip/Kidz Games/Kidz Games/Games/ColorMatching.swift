//  ColorMatching.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI
import AVFoundation

struct ColorMatching: View {
    @State private var audioPlayer: AVAudioPlayer?
    
    let showGame: String
    let colors = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"]
    @State private var randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
    
    
    var body: some View {
        VStack {
            Text("Match the Color")
                .font(.title)
            Spacer()
            HStack {
                Text("\(randomColor)")
                    .font(.system(size: 75))
            }
            HStack {
                Button(action: {
                    if randomColor == "Red" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.red)
                }
                Button(action: {
                    if randomColor == "Blue" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.blue)
                }
            }
            HStack {
                Button(action: {
                    if randomColor == "Green" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.green)
                }
                Button(action: {
                    if randomColor == "Yellow" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.yellow)
                }
            }
            HStack {
                Button(action: {
                    if randomColor == "Orange" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.orange)
                }
                Button(action: {
                    if randomColor == "Purple" {
                        playSound(soundName: "TrumpetFanfare", soundType: "mp3")
                        randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
                    } else {
                        playSound(soundName: "SadTrombone", soundType: "mp3")
                    }
                }) {
                    Rectangle()
                        .fill(Color.purple)
                }
            }
        }
    }
    
    func playSound(soundName: String, soundType: String) {
            if let url = Bundle.main.url(forResource: soundName, withExtension: soundType) {
                do {
                    try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
                    try AVAudioSession.sharedInstance().setActive(true)

                    audioPlayer = try AVAudioPlayer(contentsOf: url)
                    audioPlayer?.play()
                } catch {
                    print("Error playing sound: \(error.localizedDescription)")
                }
            } else {
                print("Sound file not found")
            }
        }
}

#Preview {
    ColorMatching(showGame: "Game")
}
