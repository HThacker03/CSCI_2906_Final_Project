//  ColorMatching.swift
//  Kidz Games
//  Created by Student on 11/25/25.

import SwiftUI

struct ColorMatching: View {
    let showGame: String
    let colors = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"]
    let randomColor = ["Red", "Blue", "Yellow", "Green", "Orange", "Purple"].randomElement()!
    
    
    var body: some View {
        VStack {
            Text("Match the Color")
                .font(.title)
            Spacer()
            HStack {
                Text("\(randomColor)")
                    .font(.system(size: 75))
            }
            HStack {
                Button(action: {
                    if randomColor == "Red" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.red)
                }
                Button(action: {
                    if randomColor == "Blue" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.blue)
                }
            }
            HStack {
                Button(action: {
                    if randomColor == "Green" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.green)
                }
                Button(action: {
                    if randomColor == "Yellow" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.yellow)
                }
            }
            HStack {
                Button(action: {
                    if randomColor == "Orange" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.orange)
                }
                Button(action: {
                    if randomColor == "Purple" {
                        print("Correct")
                    } else {
                        print("Incrorrect")
                    }
                }) {
                    Rectangle()
                        .fill(Color.purple)
                }
            }
        }
    }
}

#Preview {
    ColorMatching(showGame: "Game")
}
