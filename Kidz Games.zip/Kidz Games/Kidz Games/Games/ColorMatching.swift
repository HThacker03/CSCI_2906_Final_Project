//
//  ColorMatching.swift
//  Kidz Games
//
//  Created by Student on 11/25/25.
//

import SwiftUI

struct ColorMatching: View {
    let showGame: String
    var body: some View {
        Text(showGame)
    }
}

#Preview {
    ColorMatching(showGame: "Game")
}
