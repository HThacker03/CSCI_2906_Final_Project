//  AdditionGame.swift
//  Kidz Games
//  Created by Student on 1/8/26.

import SwiftUI

struct AdditionGame: View {
    @State private var answer: String = ""
    @State private var number1 = Int.random(in: 1...10)
    @State private var number2 = Int.random(in: 1...10)
    @State private var hideAnswer : Bool = true
    
    var body: some View {
            VStack {
                HStack {
                    Text(" \(number1) + \(number2) =")
                        .font(.system(size: 75))
                        .padding()
                }
                
                HStack {
                    TextField("?", text: $answer)
                        .padding(.leading, 180)
                        .padding(.bottom, 20)
                        .keyboardType(.numberPad)
                        .font(.system(size: 75))
                }
                HStack {
                    Button(action: {hideAnswer = false}) {
                        Image(systemName: "checkmark")
                            .font(.largeTitle)
                            .foregroundColor(.green)
                            .fontWeight(.bold)
                    }
                }
                if hideAnswer == true {
                    checkAnswer()
                        .font(.largeTitle)
                        .padding()
                        .hidden()
                }
                else {
                    checkAnswer()
                        .font(.largeTitle)
                        .padding()
                }
        //}
        Button(action: {
            number2 = Int.random(in: 1...10)
            number1 = Int.random(in: 1...10)
            hideAnswer = true
            answer = ""
        }) {
            Rectangle()
                .fill(Color.yellow)
                .frame(width: 100, height: 75)
                .cornerRadius(25)
                .overlay {
                    Text("Next")
                        .font(.title)
                        .foregroundColor(.black)
            }
        }
        .padding(20)
    }
            .background(Color.blue)
}
    
    
    @ViewBuilder
    func checkAnswer() -> some View{
        let storednumber = number1 + number2
        if Int(answer) == storednumber {
            HStack {
                Text("Correct!")
                    .foregroundColor(.green)
            }
        } else {
            HStack {
                Text("Incorrect!")
                    .foregroundColor(.red)
            }
        }
    }
}
#Preview {
    AdditionGame()
}
