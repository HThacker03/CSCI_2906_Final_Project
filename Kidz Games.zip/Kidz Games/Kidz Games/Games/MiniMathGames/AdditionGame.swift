//  AdditionGame.swift
//  Kidz Games
//  Created by Student on 1/8/26.

import SwiftUI

struct AdditionGame: View {
    @State private var answer: String = ""
    //@State private var storedAnswer: Int?
    let number1 = Int.random(in: 1...10)
    let number2 = Int.random(in: 1...10)
    
    var body: some View {
        VStack {
            HStack {
                Text(" \(number1) + \(number2) =")
                    .font(.system(size: 75))
                    .padding()
            }
                
                HStack {
                    TextField("?", text: $answer)
                        //.onSubmit (checkAnswer())
                        .padding(.leading, 180)
                        .padding(.bottom, 20)
                        .keyboardType(.numberPad)
                        .font(.system(size: 75))
                }
            HStack {
                Button(action: {checkAnswer()}) {
                    Image(systemName: "checkmark")
                        .font(.largeTitle)
                        .foregroundColor(.green)
                        .fontWeight(.bold)
                }
            }
        }
        //.background(Color.teal)
    }
    
    @ViewBuilder
    func checkAnswer() -> some View{
        let storednumber = number1 + number2
        //var correctCount = 0
        if Int(answer) == storednumber {
            //correctCount += 1
            HStack {
                Text("Correct!")
            }
        } else {
            Text("Incorrect!")
        }
    }
}

#Preview {
    AdditionGame()
}
