//  AdditionGame.swift
//  Kidz Games
//  Created by Student on 1/8/26.

import SwiftUI

struct AdditionGame: View {
    @State private var answer: String = ""
    //@State private var storedAnswer: Int?
    let number1 = Int.random(in: 1...10)
    let number2 = Int.random(in: 1...10)
    
    var body: some View {
            HStack {
                Text(" \(number1) + \(number2) =")
                    .font(.largeTitle)
                    .padding()
                
                Spacer()
                
                TextField("?", text: $answer)
                //.padding()
                    .keyboardType(.numberPad)
                    .font(.largeTitle)
            }
            HStack {
                Button(action: {checkAnswer()}) {
                    Image(systemName: "checkmark")
                        .font(.largeTitle)
                        .foregroundColor(.green)
                        .fontWeight(.bold)
            }
        }
    }
    
    func checkAnswer() {
        let storednumber = number1 + number2
        if Int(answer) == storednumber {
            print("Correct!")
        } else {
            print("Incorrect!")
        }
    }
}

#Preview {
    AdditionGame()
}
