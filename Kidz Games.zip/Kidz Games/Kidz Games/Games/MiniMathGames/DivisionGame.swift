//
//  DivisionGame.swift
//  Kidz Games
//
//  Created by Student on 1/8/26.
//

import SwiftUI

struct DivisionGame: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    DivisionGame()
}
