//  SubtractionGame.swift
//  Kidz Games
//  Created by Student on 1/8/26.

import SwiftUI

struct SubtractionGame: View {
    @State private var answer: String = ""
    @State private var number1 = Int.random(in: 1...10)
    @State private var number2 = Int.random(in: 1...10)
    @State private var firstNumber = 0
    @State private var secondNumber = 0
    @State private var hideAnswer : Bool = true
    
    var body: some View {
        ZStack {
            VStack {
                HStack {
                    Text(" \(firstNumber) - \(secondNumber) =")
                        .font(.system(size: 75))
                        .padding()
                        .onAppear {
                            numberOrder()
                        }
                }
                
                HStack {
                    TextField("?", text: $answer)
                        .padding(.leading, 180)
                        .padding(.bottom, 20)
                        .keyboardType(.numberPad)
                        .font(.system(size: 75))
                }
                HStack {
                    Button(action: {hideAnswer = false}) {
                        Image(systemName: "checkmark")
                            .font(.largeTitle)
                            .foregroundColor(.green)
                            .fontWeight(.bold)
                    }
                }
                if hideAnswer == true {
                    checkAnswer()
                        .font(.largeTitle)
                        .padding()
                        .hidden()
                }
                else {
                    checkAnswer()
                        .font(.largeTitle)
                        .padding()
                }
                Button(action: {
                    number2 = Int.random(in: 1...10)
                    number1 = Int.random(in: 1...10)
                    hideAnswer = true
                    answer = ""
                    numberOrder()
                }) {
                    Rectangle()
                        .fill(Color.purple)
                        .frame(width: 100, height: 75)
                        .cornerRadius(25)
                        .overlay {
                            Text("Next")
                                .font(.title)
                                .foregroundColor(.black)
                        }
                }
                .padding()
            }
            .background(Color.white)
        }
    .frame(maxWidth: .infinity, maxHeight: .infinity)
    .background(Color.purple.opacity(0.6))
    .ignoresSafeArea()
    }
    
    @ViewBuilder
    func checkAnswer() -> some View{
        let storednumber = firstNumber - secondNumber
        if Int(answer) == storednumber {
            HStack {
                Text("Correct!")
                    .foregroundColor(.green)
            }
        } else {
            HStack {
                Text("Incorrect!")
                    .foregroundColor(.red)
            }
        }
    }
    
    func numberOrder() {
            if number1 > number2 {
                firstNumber = number1
                secondNumber = number2
            } else {
                firstNumber = number2
                secondNumber = number1
            }
        }

}

#Preview {
    SubtractionGame()
}
