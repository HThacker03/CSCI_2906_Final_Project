//  SubtractionGame.swift
//  Kidz Games
//  Created by Student on 1/8/26.

import SwiftUI

struct SubtractionGame: View {
    @State private var answer: String = ""
    let number1 = Int.random(in: 1...10)
    let number2 = Int.random(in: 1...10)
    @State private var firstNumber = 0
    @State private var secondNumber = 0
    @State private var hideAnswer : Bool = true
    
    var body: some View {
        VStack {
            HStack {
                Text(" \(firstNumber) - \(secondNumber) =")
                    .font(.system(size: 75))
                    .padding()
                    .onAppear {
                        numberOrder()
                    }
            }
            
            HStack {
                TextField("?", text: $answer)
                    .padding(.leading, 180)
                    .padding(.bottom, 20)
                    .keyboardType(.numberPad)
                    .font(.system(size: 75))
            }
            HStack {
                Button(action: {hideAnswer = false}) {
                    Image(systemName: "checkmark")
                        .font(.largeTitle)
                        .foregroundColor(.green)
                        .fontWeight(.bold)
                }
            }
            if hideAnswer == true {
                checkAnswer()
                    .font(.largeTitle)
                    .padding()
                    .hidden()
            }
            else {
                checkAnswer()
                    .font(.largeTitle)
                    .padding()
            }
        }
        NavigationStack {
            NavigationLink(destination: SubtractionGame()) {
                Rectangle()
                    .fill(Color.purple)
                    .frame(width: 100, height: 75)
                    .cornerRadius(25)
                    .overlay {
                        Text("Next")
                            .font(.title)
                            .foregroundColor(.black)
                    }
            }
        }
    }
    
    @ViewBuilder
    func checkAnswer() -> some View{
        let storednumber = firstNumber - secondNumber
        if Int(answer) == storednumber {
            HStack {
                Text("Correct!")
                    .foregroundColor(.green)
            }
        } else {
            HStack {
                Text("Incorrect!")
                    .foregroundColor(.red)
            }
        }
    }
    
    func numberOrder() {
            if number1 > number2 {
                firstNumber = number1
                secondNumber = number2
            } else {
                firstNumber = number2
                secondNumber = number1
            }
        }

}

#Preview {
    SubtractionGame()
}
