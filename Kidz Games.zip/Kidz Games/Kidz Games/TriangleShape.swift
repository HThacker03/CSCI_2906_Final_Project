//  TriangleShape.swift
//  Kidz Games
//  Created by Student on 12/12/25.

import SwiftUI

struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()

        let topPoint = CGPoint(x: rect.midX, y: rect.minY)
        let rightPoint = CGPoint(x: rect.maxX, y: rect.maxY)
        let leftPoint = CGPoint(x: rect.minX, y: rect.maxY)

        path.move(to: topPoint)
        path.addLine(to: rightPoint)
        path.addLine(to: leftPoint)
        path.closeSubpath()

        return path
    }
}

